#!/usr/bin/env python3
"""RICOS PRG TO LVLLVL: Oil's Well C64 screen data -> LVLLVL native JSON + static PRGs.

Source is identified by the known COPY SOFT relocation structure; this tool does
not claim exact palette/raster reconstruction of the running game.
"""
import argparse
import base64
import hashlib
import json
import sys
import zipfile
from pathlib import Path

SHA_ORIGINAL = '26f5ff6d362f5018e74761d73c6e273ecc332d36e0b6992c65126683474520bd'
# Actual COPY SOFT loader copies source $0900-$59FF into $8000-$D0FF.
SOURCE_START = 0x0900
LOAD_ADDR = 0x0801
CHAR_ADDR = 0x9A00
MAP_BASE = 0xA000
MAP_SIZE = 0x400
CHAR_SIZE = 1024
CHAR_COUNT = 128
WIDTH, HEIGHT = 40, 25
C64 = [0x000000,0xffffff,0x68372b,0x70a4b2,0x6f3d86,0x588d43,
       0x352879,0xb8c76f,0x6f4f25,0x433900,0x9a6759,0x444444,
       0x6c6c6c,0x9ad284,0x6c5eb5,0x959595]


def fetch_relocated(prg, address, size):
    # PRG header 2 bytes; source address = $0900 + (address - $8000)
    off = 2 + SOURCE_START - LOAD_ADDR + address - 0x8000
    result = prg[off:off + size]
    if len(result) != size:
        raise ValueError('Bloque incompleto desde $%04X' % address)
    return result


def extract(raw):
    if len(raw) < 38405 or raw[:2] != b'\x01\x08':
        raise ValueError('No se reconoce la version COPY SOFT de Oil\'s Well')
    # Machine code at reloaded $8004 is CBM80 cartridge signature.
    if fetch_relocated(raw, 0x8004, 5) != bytes.fromhex('c3c2cd3830'):
        raise ValueError('Falta firma PETSCII CBM80: PRG no compatible')
    tiles = fetch_relocated(raw, CHAR_ADDR, CHAR_SIZE)
    maps = [fetch_relocated(raw, MAP_BASE + n*MAP_SIZE, MAP_SIZE) for n in range(8)]
    if any(max(m[:1000]) >= CHAR_COUNT for m in maps):
        raise ValueError('Un indice del mapa excede el tileset de 128 caracteres')
    return tiles, maps


def lvllvl_json(tiles, maps, mode='c64multicolor', name='OILS WELL - 8 LEVELS'):
    """Follow jaammees/lvllvl ExportJson.exportJsonAs native structure.
    tileSet.tiles data[0] holds row-major 8x8 pixel values, not packed bytes.
    """
    charset = tiles + bytes(1024) # 256 slots for editing, source has 128.
    tile_objects = []
    for i in range(256):
        glyph = charset[i*8:(i+1)*8]
        px = [(glyph[y] >> (7-x)) & 1 for y in range(8) for x in range(8)]
        tile_objects.append({'data':[px]})
    tid, cid = 1, 2
    palette = {'id':cid,'name':'Commodore 64 (preview palette)', 'version':1,
               'data':C64, 'across':8,'down':2,'maps':[]}
    ts = {'id':tid,'name':'Oil\'s Well original 128 chars (padded to 256)',
          'version':1,'width':8,'height':8,'type':'ascii','sortMethods':['index'],
          'paletteLayouts':[],'tiles':tile_objects}
    layerframes = []
    for raw in maps:
        # Color RAM is not present in the original PRG. WHITE = preview only.
        rows = [[{'t':raw[y*WIDTH + x],'fc':1,'bc':-1} for x in range(WIDTH)]
                for y in range(HEIGHT)]
        layerframes.append({'data':rows,'bgColor':0,'borderColor':0})
    layer = {'id':3, 'label':'OILS WELL - map indices',
             'gridWidth':WIDTH,'gridHeight':HEIGHT,'colorPerMode':'cell',
             'screenMode':mode,'cellWidth':8,'cellHeight':8,
             'tileSetId':tid,'colorPaletteId':cid,'blockMode':False,
             'frames':layerframes}
    return {
        'version':1,
        'tileSet':ts,
        'colorPalette':palette,
        'tileMap':{
            'name':name,
            'frameRanges':[{'start':0,'end':len(maps)}],
            'frames':[{'duration':12} for _ in maps],
            'layers':[layer]
        },
        'r icoInfo'.replace(' ',''): {
            'source':'Oil\'s Well COPY SOFT PRG',
            'originalRuntimeMode':'Raster split: bitmap HIRES and multicolor character mode',
            'editorRepresentation':mode,
            'colorRam':'PROVISIONAL (white / all cells), not recovered from runtime',
            'warning':'PRGs are static viewers; JSON cannot encode raster mode switching',
            'frameMeanings':[f'Level {i:02d}' for i in range(1,len(maps)+1)],
        }
    }


def make_prg(stub, tiles, m):
    if len(stub)!=150 or stub[:2]!=b'\x01\x08':
        raise ValueError('viewer_stub.bin invalido')
    # Stub copies 1024 bytes to $6000, then 1024 to $7000; both within VIC bank $4000.
    return stub + m + tiles


def render_level_png(tiles, m):
    try:
        from PIL import Image
        from io import BytesIO
    except ImportError:
        return None
    im = Image.new('RGB', (320,200), (0,0,0))
    pix = im.load()
    for p, code in enumerate(m[:1000]):
        x0=(p%40)*8;y0=(p//40)*8
        for row in range(8):
            bits=tiles[code*8+row]
            for x in range(8):
                if bits&(0x80>>x): pix[x0+x,y0+row]=(255,255,255)
    out=BytesIO();im.resize((640,400), resample=Image.Resampling.NEAREST).save(out,format='PNG')
    return out.getvalue()


def make_bundle(raw, stub):
    t, maps = extract(raw)
    files={}
    files['LVLLVL/OILS_WELL_8_NIVELES.json']=json.dumps(lvllvl_json(t,maps),ensure_ascii=False,separators=(',',':')).encode()
    files['LVLLVL/OILS_WELL_8_NIVELES_HIRES.json']=json.dumps(lvllvl_json(t,maps,'c64standard'),ensure_ascii=False,separators=(',',':')).encode()
    files['BIN/TILESET_ORIGINAL_128.bin']=t
    files['BIN/TILESET_PAD_256.bin']=t+bytes(1024)
    for k,m in enumerate(maps,1):
        name=f'LEVEL_{k:02d}'
        files[f'BIN/{name}_MAP_1024_ORIGINAL.bin']=m
        files[f'BIN/{name}_MAP_40x25.bin']=m[:1000]
        files[f'BIN/{name}_COLOR_PREVIEW_NO_ORIGINAL.bin']=bytes([1])*1000
        files[f'PRG/OILS_WELL_{name}_ESTATICO.prg']=make_prg(stub,t,m)
        files[f'LVLLVL/{name}.json']=json.dumps(lvllvl_json(t,[m],name=name),ensure_ascii=False,separators=(',',':')).encode()
        p=render_level_png(t,m)
        if p: files[f'PREVIEWS/{name}.png']=p
    files['README.txt']=(
        'RICOS PRG TO LVLLVL — OIL\'S WELL TEST01\n'
        '8 niveles separados del PRG real de COPY SOFT.\n\n'
        'Archivo principal: LVLLVL/OILS_WELL_8_NIVELES.json\n'
        'Compatible en estructura con Export > JSON nativo de jaammees/lvllvl.\n'
        'tileSet: 128 caracteres originales 8x8, mas 128 vacios.\n'
        'tileMap: 8 frames, pantalla 40x25. Los indices no se reordenaron.\n'
        'colorPalette: paleta C64. Color RAM real NO recuperada; blanco provisional.\n'
        'Modo JSON default c64multicolor: se conservan caracteristicas de\n'
        'caracter C64 en LVLLVL; con color de celda 1 opera en hires.\n'
        'Existe una variante HIRES (c64standard) para compatibilidad.\n'
        'PRG: 8 visualizadores hires del mapa, SIN el raster split original.\n'
        'El original alterna bitmap hires ($D011=$3B/$D016=$08)\n'
        'y multicolor caracteres ($D011=$1B/$D016=$18).\n'
        'Un unico layer LVLLVL no puede reproducir ambos modos simultaneamente.\n'
        'Esta exportacion no incluye sprites, enemigos ni atributos de colision.\n'
        'No esta validada aun en UI LVLLVL/VICE real.\n'
    ).encode('utf-8')
    manifest={'sourceSha256':hashlib.sha256(raw).hexdigest(),
              'isOriginalSource':hashlib.sha256(raw).hexdigest()==SHA_ORIGINAL,
              'levelCount':8,
              'tilesetAddress':'$9A00','tilesetBytes':1024,
              'mapAddresses':[f'${MAP_BASE+i*MAP_SIZE:04X}' for i in range(8)],
              'note':'Colors are preview-only; raster split not preserved in PRG viewers.',
              'filesSha256':{k:hashlib.sha256(v).hexdigest() for k,v in files.items()}}
    files['MANIFEST.json']=json.dumps(manifest,indent=2,ensure_ascii=False).encode()
    return files


def main():
    ap=argparse.ArgumentParser(description='Oil\'s Well C64 -> 8 frames LVLLVL and static PRGs')
    ap.add_argument('prg',type=Path)
    ap.add_argument('--output',default='OILS_WELL_LVLLVL_TEST01.zip')
    args=ap.parse_args()
    stub=base64.b64decode('AQgLCAoAnjIwNjEAAAB42KkAjRHQqZWF+6kIhfypAIX9qWCF/iCCCKmVhfupDIX8qQCF/alwhf4gggiiAKkBnQDYnQDZnQDanQDb6NDxqQCNFdCNINCNIdCNItCNI9CtAt0JA40C3a0A3Sn8CQKNAN2pjI0Y0KkIjRbQqRuNEdBMfwiiBKAAsfuR/cjQ+eb85v7K0PJg')
    files=make_bundle(args.prg.read_bytes(),stub)
    with zipfile.ZipFile(args.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name, content in sorted(files.items()):z.writestr(name,content)
    print('OK:',args.output,'entries:',len(files))


if __name__=='__main__':
    try: main()
    except (ValueError,FileNotFoundError) as exc:
        sys.exit('ERROR: '+str(exc))
