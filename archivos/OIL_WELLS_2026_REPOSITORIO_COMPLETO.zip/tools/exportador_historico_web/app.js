/* RICOS PRG TO LVLLVL — offline browser exporter for Oil's Well COPY SOFT. */
'use strict';
const STUB_B64 = 'AQgLCAoAnjIwNjEAAAB42KkAjRHQqZWF+6kIhfypAIX9qWCF/iCCCKmVhfupDIX8qQCF/alwhf4gggiiAKkBnQDYnQDZnQDanQDb6NDxqQCNFdCNINCNIdCNItCNI9CtAt0JA40C3a0A3Sn8CQKNAN2pjI0Y0KkIjRbQqRuNEdBMfwiiBKAAsfuR/cjQ+eb85v7K0PJg';
const C64=[0x000000,0xffffff,0x68372b,0x70a4b2,0x6f3d86,0x588d43,0x352879,0xb8c76f,0x6f4f25,0x433900,0x9a6759,0x444444,0x6c6c6c,0x9ad284,0x6c5eb5,0x959595];
const el=id=>document.getElementById(id);
const encoder=new TextEncoder();
const byteArray=b64=>Uint8Array.from(atob(b64),c=>c.charCodeAt(0));
const sourceStart=0x0900, sourceLoad=0x0801;
let src=null, tiles=null, levels=null;
function block(address,size){
  const start=2+sourceStart-sourceLoad+address-0x8000;
  if(start<0||start+size>src.length)throw Error('Bloque fuera del PRG: $'+address.toString(16));
  return src.slice(start,start+size);
}
function parse(data){
  src=data;
  if(src.length<38405||src[0]!==1||src[1]!==8)throw Error('No se reconoce Oil\'s Well PRG con COPY SOFT.');
  if(Array.from(block(0x8004,5)).join(',')!=='195,194,205,56,48')throw Error('No se encontró la cabecera CBM80 PETSCII.');
  const t=block(0x9a00,1024);let maps=Array.from({length:8},(_,i)=>block(0xa000+i*1024,1024));
  if(maps.some(m=>m.slice(0,1000).some(c=>c>=128)))throw Error('Índice fuera del charset: formato no compatible.');
  tiles=t;levels=maps;return true;
}
function lvllvl(maps,mode,name){
  let full=new Uint8Array(2048);full.set(tiles);
  const chars=Array.from({length:256},(_,c)=>({data:[Array.from({length:64},(_,p)=>(full[c*8+(p>>3)]>>(7-(p&7)))&1)]}));
  const frames=maps.map(map=>({data:Array.from({length:25},(_,y)=>Array.from({length:40},(_,x)=>({t:map[y*40+x],fc:1,bc:-1}))),bgColor:0,borderColor:0}));
  return {version:1,
    tileSet:{id:1,name:'Oil\'s Well original charset (128 padded to 256)',version:1,width:8,height:8,type:'ascii',sortMethods:['index'],paletteLayouts:[],tiles:chars},
    colorPalette:{id:2,name:'Commodore 64 (preview)',version:1,data:C64,across:8,down:2,maps:[]},
    tileMap:{name,frameRanges:[{start:0,end:maps.length}],frames:maps.map(()=>({duration:12})),layers:[{id:3,label:'Oil\'s Well Map',gridWidth:40,gridHeight:25,colorPerMode:'cell',screenMode:mode,cellWidth:8,cellHeight:8,tileSetId:1,colorPaletteId:2,blockMode:false,frames}]},
    ricoInfo:{originalRuntimeMode:'Raster split bitmap HIRES + multicolor character',editorRepresentation:mode,colorRam:'UNAVAILABLE: white preview only',warning:'Static viewers do not reproduce original raster split; no enemies or sprite overlay.'}};
}
const text=o=>encoder.encode(JSON.stringify(o));
const name=i=>`LEVEL_${String(i+1).padStart(2,'0')}`;
function viewer(map){const b=new Uint8Array(150+1024+1024);b.set(byteArray(STUB_B64));b.set(map,150);b.set(tiles,1174);return b;}
function paint(canvas,map,tile){
  const ctx=canvas.getContext('2d');let im=ctx.createImageData(canvas.width,canvas.height);
  im.data.fill(255);
  for(let y=0;y<canvas.height;y++)for(let x=0;x<canvas.width;x++){
    const t=tile?((y>>3)*16+(x>>3)):map[(y>>3)*40+(x>>3)];
    const on=!!(tiles[t*8+(y&7)]&(0x80>>(x&7)));
    const p=4*(y*canvas.width+x);let v=on?240:0;im.data[p]=im.data[p+1]=im.data[p+2]=v;
  }
  ctx.putImageData(im,0,0);
}
function render(){const i=+el('level').value;paint(el('map'),levels[i],false);paint(el('tileset'),levels[i],true);}
function save(name,bytes){const blob=new Blob([bytes],{type:'application/octet-stream'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
// Portable ZIP method 0 writer. No third-party libraries, works offline.
const crcTable=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n&1)?(0xedb88320^(n>>>1)):(n>>>1);return n>>>0;});
function crc32(arr){let n=0xffffffff;for(let b of arr)n=crcTable[(n^b)&255]^(n>>>8);return (n^0xffffffff)>>>0;}
function u16(dv,p,n){dv.setUint16(p,n,true);}function u32(dv,p,n){dv.setUint32(p,n,true);}
function zip(files){const out=[],dir=[];let off=0;for(const [filename,raw] of files){
  const nameBytes=encoder.encode(filename);const data=typeof raw==='string'?encoder.encode(raw):raw;const crc=crc32(data);
  let local=new Uint8Array(30+nameBytes.length),v=new DataView(local.buffer);
  u32(v,0,0x04034b50);u16(v,4,20);u16(v,6,0x0800);u16(v,8,0);u32(v,14,crc);u32(v,18,data.length);u32(v,22,data.length);u16(v,26,nameBytes.length);local.set(nameBytes,30);
  out.push(local,data);let central=new Uint8Array(46+nameBytes.length),cv=new DataView(central.buffer);
  u32(cv,0,0x02014b50);u16(cv,4,20);u16(cv,6,20);u16(cv,8,0x0800);u16(cv,10,0);u32(cv,16,crc);u32(cv,20,data.length);u32(cv,24,data.length);u16(cv,28,nameBytes.length);u32(cv,42,off);central.set(nameBytes,46);dir.push(central);off+=local.length+data.length;
}const dirlen=dir.reduce((n,c)=>n+c.length,0);let end=new Uint8Array(22),e=new DataView(end.buffer);u32(e,0,0x06054b50);u16(e,8,files.length);u16(e,10,files.length);u32(e,12,dirlen);u32(e,16,off);return new Blob([...out,...dir,end],{type:'application/zip'});}
function downloadBundle(){const mode=el('mode').value;const files=[];let json=(arr,n)=>text(lvllvl(arr,mode,n));
  files.push(['LVLLVL/OILS_WELL_8_NIVELES.json',json(levels,'OILS WELL - 8 LEVELS')]);
  files.push(['LVLLVL/OILS_WELL_8_NIVELES_HIRES.json',text(lvllvl(levels,'c64standard','OILS WELL - 8 LEVELS'))]);
  files.push(['BIN/TILESET_ORIGINAL_128.bin',tiles]);let padded=new Uint8Array(2048);padded.set(tiles);files.push(['BIN/TILESET_PAD_256.bin',padded]);
  levels.forEach((m,i)=>{const n=name(i);files.push([`BIN/${n}_MAP_1024_ORIGINAL.bin`,m],[`BIN/${n}_MAP_40x25.bin`,m.slice(0,1000)],[`BIN/${n}_COLOR_PREVIEW_NO_ORIGINAL.bin`,new Uint8Array(1000).fill(1)],[`PRG/OILS_WELL_${n}_ESTATICO.prg`,viewer(m)],[`LVLLVL/${n}.json`,json([m],n)]);});
  files.push(['README.txt','RICOS PRG TO LVLLVL TEST01\nLos indices 0-127 son originales.\nLos colores son PROVISIONALES, y los PRG visualizadores no reconstruyen el raster split.\nEl JSON tiene 8 frames y charset embebido.\n']);
  const blob=zip(files);let url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='OILS_WELL_RICOS_LVLLVL_TEST01.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
el('source').addEventListener('change',async ev=>{try{const file=ev.target.files[0];if(!file)return;parse(new Uint8Array(await file.arrayBuffer()));el('filename').textContent=file.name;el('level').innerHTML=levels.map((_,i)=>`<option value="${i}">Nivel ${i+1}</option>`).join('');for(const id of ['level','bundle','alljson','onejson','oneprg','tiles'])el(id).disabled=false;el('status').textContent='PASS extracción RAW: 8 mapas (1024 bytes), tileset (1024 bytes), 128 índices válidos. Color RAM real no extraída.';render();}catch(e){el('status').textContent='FAIL: '+e.message;levels=null;}});
el('level').addEventListener('change',render);
el('bundle').addEventListener('click',downloadBundle);
el('alljson').addEventListener('click',()=>save('OILS_WELL_8_NIVELES.json',text(lvllvl(levels,el('mode').value,'OILS WELL - 8 LEVELS'))));
el('onejson').addEventListener('click',()=>{const i=+el('level').value;save(name(i)+'.json',text(lvllvl([levels[i]],el('mode').value,name(i))));});
el('oneprg').addEventListener('click',()=>{const i=+el('level').value;save('OILS_WELL_'+name(i)+'_ESTATICO.prg',viewer(levels[i]));});
el('tiles').addEventListener('click',()=>save('OILS_WELL_TILESET_ORIGINAL.bin',tiles));
